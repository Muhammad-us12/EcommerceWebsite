 
        <?php $__env->startSection('style'); ?>
        <link href="<?php echo e(asset('public/adminPanel/assets/css/vendor/dataTables.bootstrap5.css')); ?>" rel="stylesheet" type="text/css" />
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('sidebare'); ?>

        <?php echo $__env->make('vendorPanel/sidebare', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php $__env->stopSection(); ?>
         <?php $__env->startSection('content'); ?>       
                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                            <?php if(session('success')): ?>
                                               

                                               <div id="success-alert-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
                                                   <div class="modal-dialog modal-sm">
                                                       <div class="modal-content modal-filled bg-success">
                                                           <div class="modal-body p-4">
                                                               <div class="text-center">
                                                                   <i class="dripicons-checkmark h1"></i>
                                                                   <h4 class="mt-2">Well Done!</h4>
                                                                   <p class="mt-3"><?php echo e(session('success')); ?></p>
                                                                   <button type="button" class="btn btn-light my-2" data-bs-dismiss="modal">Continue</button>
                                                               </div>
                                                           </div>
                                                       </div><!-- /.modal-content -->
                                                   </div><!-- /.modal-dialog -->
                                               </div>

                                               
                                               <?php endif; ?>

                                               <?php if(session('error')): ?>
                                               <div id="error-alert-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
                                                   <div class="modal-dialog modal-sm">
                                                       <div class="modal-content modal-filled bg-danger">
                                                           <div class="modal-body p-4">
                                                               <div class="text-center">
                                                                   <i class="dripicons-wrong h1"></i>
                                                                   <h4 class="mt-2">Oh snap!</h4>
                                                                   <p class="mt-3"><?php echo e(session('error')); ?></p>
                                                                   <button type="button" class="btn btn-light my-2" data-bs-dismiss="modal">Continue</button>
                                                               </div>
                                                           </div>
                                                       </div><!-- /.modal-content -->
                                                   </div><!-- /.modal-dialog -->
                                               </div><!-- /.modal -->
                                               <?php endif; ?>
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        
                                    </div>
                                    <h4 class="page-title">Vendor Details</h4>
                                    <?php if($errors->any()): ?>
                                        <div class="alert alert-danger">
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row mb-2">
                                            <div class="col-sm-5">
                                                <h4 class="page-title">Vendor Details</h4>
                                            </div>
                                            <div class="col-sm-7">
                                                <div class="text-sm-end">
                                                <!-- <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#standard-modal"><i class="mdi mdi-plus-circle me-2"></i>Add Slider</button> -->
                                                </div>
                                            </div><!-- end col-->
                                        </div>
                
                                        <div class="row">
                                            <div class="col-md-12">
                                                <?php if($vendor->vendor): ?>
                                                <form action="<?php echo e(URL::to('vendor/on-boarding/update/'.$vendor->vendor->id)); ?>" enctype="multipart/form-data" method="post">
                                                    <?php else: ?>
                                                    <form action="<?php echo e(URL::to('vendor/on-boarding/save')); ?>" enctype="multipart/form-data" method="post">

                                                <?php endif; ?>
                                                <?php echo csrf_field(); ?>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="phone" class="form-label">Name</label>
                                                            <input type="text" name="userName" readonly required value="<?php echo e($vendor->name); ?>" class="form-control" id="userName" placeholder="Enter userName">
                                                            <?php $__errorArgs = ['userName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <p class="text-danger mt-2"><?php echo e($message); ?></p>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="phone" class="form-label">Email</label>
                                                            <input type="text" name="email" readonly required value="<?php echo e($vendor->email); ?>" class="form-control" id="email" placeholder="Enter email">
                                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <p class="text-danger mt-2"><?php echo e($message); ?></p>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="phone" class="form-label">Phone</label>
                                                            <input type="text" name="phone" required value="<?php echo e($vendor->vendor->phone ?? ''); ?>" class="form-control" id="phone" placeholder="Enter Phone">
                                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <p class="text-danger mt-2"><?php echo e($message); ?></p>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                 
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="city" class="form-label">City</label>
                                                            <input type="text" name="city" required value="<?php echo e($vendor->vendor->city ?? ''); ?>" class="form-control" id="city" placeholder="Enter City">
                                                            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <p class="text-danger mt-2"><?php echo e($message); ?></p>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="cnic" class="form-label">CNIC</label>
                                                            <input type="text" name="cnic" required value="<?php echo e($vendor->vendor->cnic ?? ''); ?>" class="form-control" id="cnic" placeholder="Enter CNIC">
                                                            <?php $__errorArgs = ['cnic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <p class="text-danger mt-2"><?php echo e($message); ?></p>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="gender" class="form-label">Gender</label>
                                                            <select name="gender" required class="form-control" id="gender">
                                                                <option value="" disabled selected>Select Gender</option>
                                                                <option value="male" <?php if(isset($vendor->vendor->gender)): ?> <?php echo e($vendor->vendor->gender == 'male' ? 'selected' : ''); ?> <?php endif; ?>>Male</option>
                                                                <option value="female" <?php if(isset($vendor->vendor->gender)): ?> <?php echo e($vendor->vendor->gender == 'female' ? 'selected' : ''); ?> <?php endif; ?>>Female</option>
                                                                <option value="other" <?php if(isset($vendor->vendor->gender)): ?> <?php echo e($vendor->vendor->gender == 'other' ? 'selected' : ''); ?> <?php endif; ?>>Other</option>
                                                            </select>
                                                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <p class="text-danger mt-2"><?php echo e($message); ?></p>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="bank_account_number" class="form-label">Bank Account Number</label>
                                                            <input type="text" name="bank_account_number" required value="<?php echo e($vendor->vendor->bank_account_number ?? ''); ?>" class="form-control" id="bank_account_number" placeholder="Enter Bank Account Number">
                                                            <?php $__errorArgs = ['bank_account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <p class="text-danger mt-2"><?php echo e($message); ?></p>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="bank_name" class="form-label">Bank Name</label>
                                                            <input type="text" name="bank_name" required value="<?php echo e($vendor->vendor->bank_name ?? ''); ?>" class="form-control" id="bank_name" placeholder="Enter Bank Name">
                                                            <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <p class="text-danger mt-2"><?php echo e($message); ?></p>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="mb-3">
                                                            <label for="address" class="form-label">Address</label>
                                                            <input type="text" name="address" required value="<?php echo e($vendor->vendor->address ?? ''); ?>" class="form-control" id="address" placeholder="Enter Address">
                                                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <p class="text-danger mt-2"><?php echo e($message); ?></p>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                  
                                                    <div class="col-md-12">
                                                        <button type="submit" class="btn btn-success">Update</button>
                                                    </div>
                                                </div>
                                               


                                             
                                                
                                                </form>
                                            </div>
                                        </div>
                                        
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col -->
                        </div>
                     
                        <!-- end row -->

                    </div>

         <?php $__env->stopSection(); ?>

         <?php $__env->startSection('scripts'); ?>
         <script src="<?php echo e(asset('adminPanel/assets/js/vendor/jquery.dataTables.min.js')); ?>"></script>
         <script src="<?php echo e(asset('adminPanel/assets/js/vendor/dataTables.bootstrap5.js')); ?>"></script>
         
            <script>
                   <?php if(session('success')): ?>
                        $(document).ready(function(){
                            $("#success-alert-modal").modal('show');
                        })  
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        $(document).ready(function(){
                                $("#error-alert-modal").modal('show');
                        })
                    <?php endif; ?>

                $("#scroll-horizontal-datatable").DataTable({scrollX:!0,language:{paginate:{previous:"<i class='mdi mdi-chevron-left'>",next:"<i class='mdi mdi-chevron-right'>"}},drawCallback:function(){$(".dataTables_paginate > .pagination").addClass("pagination-rounded")}})
            </script>            
         <?php $__env->stopSection(); ?>
                    <!-- container -->

                
<?php echo $__env->make('vendorPanel/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usama/Desktop/CustomProjects/ecommerceMultiVendor/resources/views/vendorPanel/onboarding.blade.php ENDPATH**/ ?>