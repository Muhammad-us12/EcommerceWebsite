 
 <?php $__env->startSection('content'); ?>        
   <!-- breadcrumb-area start -->
   <div class="breadcrumb-area bg-grey">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="breadcrumb-list">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active">Checkout Page</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumb-area end -->
    
    
    <!-- content-wraper start -->
    <div class="content-wraper">
        <div class="container">
            
            <!-- checkout-details-wrapper start -->
            <div class="checkout-details-wrapper">
                <div class="row">
                <div class="col-lg-6 col-md-6">
    <!-- billing-details-wrap start -->
    <div class="billing-details-wrap">
        <form action="<?php echo e(route('checkout.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <h3 class="shoping-checkboxt-title">Billing Details</h3>
            <div class="row">
                <div class="col-lg-6">
                    <p class="single-form-row">
                        <label>First name <span class="required">*</span></label>
                        <input type="text" name="first_name" value="<?php echo e(old('first_name')); ?>" required>
                        <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </p>
                </div>
                <div class="col-lg-6">
                    <p class="single-form-row">
                        <label>Last name <span class="required">*</span></label>
                        <input type="text" name="last_name" value="<?php echo e(old('last_name')); ?>" required>
                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </p>
                </div>
                <div class="col-lg-12">
                    <p class="single-form-row">
                        <label>Company name</label>
                        <input type="text" name="company_name" value="<?php echo e(old('company_name')); ?>">
                        <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </p>
                </div>
                <div class="col-lg-12">
                    <div class="single-form-row">
                        <label>Country <span class="required">*</span></label>
                        <select name="country" class="form-control" required>
                            <option>Select Country...</option>
                            <?php if(isset($locations)): ?>
                                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($location['name']); ?>" <?php echo e(old('country') == $location['name'] ? 'selected' : ''); ?>><?php echo e($location['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-lg-12">
                    <p class="single-form-row">
                        <label>Street address <span class="required">*</span></label>
                        <input type="text" placeholder="House number and street name" name="street_address" value="<?php echo e(old('street_address')); ?>" required>
                        <?php $__errorArgs = ['street_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </p>
                </div>
                <div class="col-lg-12">
                    <p class="single-form-row">
                        <input type="text" placeholder="Apartment, suite, unit etc. (optional)" name="apartment" value="<?php echo e(old('apartment')); ?>">
                        <?php $__errorArgs = ['apartment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </p>
                </div>
                <div class="col-lg-12">
                    <p class="single-form-row">
                        <label>Phone <span class="required">*</span></label>
                        <input type="text" name="phone" value="<?php echo e(old('phone')); ?>" required>
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </p>
                </div>
                <div class="col-lg-12">
                    <p class="single-form-row">
                        <label>Email address <span class="required">*</span></label>
                        <input type="email" name="email" value="<?php echo e(old('email')); ?>" required>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </p>
                </div>
                <div class="col-lg-12">
                    <p class="single-form-row">
                        <label>Password <span class="required">*</span></label>
                        <input type="password" name="password" required>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </p>
                </div>
                <div class="col-lg-12">
                    <p class="single-form-row">
                        <label>Confirm Password <span class="required">*</span></label>
                        <input type="password" name="password_confirmation" required>
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </p>
                </div>
                <div class="col-lg-12">
                    <p class="single-form-row m-0">
                        <label>Order notes</label>
                        <textarea placeholder="Notes about your order, e.g. special notes for delivery." name="order_notes" class="checkout-mess" rows="2" cols="5"><?php echo e(old('order_notes')); ?></textarea>
                        <?php $__errorArgs = ['order_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger mt-2"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </p>
                </div>
                <div class="col-lg-12">
                    <div class="order-button-payment">
                        <input type="submit" value="Place order" />
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- billing-details-wrap end -->
</div>


                    <div class="col-lg-6 col-md-6">
                        <!-- your-order-wrapper start -->
                        <div class="your-order-wrapper">
                            <h3 class="shoping-checkboxt-title">Your Order</h3>
                            <!-- your-order-wrap start-->
                            <div class="your-order-wrap">
                                <!-- your-order-table start -->
                                <div class="your-order-table table-responsive">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th class="product-name">Product</th>
                                                <th class="product-total">Total</th>
                                            </tr>							
                                        </thead>
                                        <tbody>
                                            <tr class="cart_item">
                                                <td class="product-name">
                                                    <img src="<?php echo e($cart['product']->getFirstMediaUrl('image')); ?>" alt="">
                                                </td>
                                                <td class="product-name">
                                                    <h4><?php echo e($cart['product']->name); ?></h4>
                                                    
                                                    <br>
                                                    <b><?php echo e($cart['price']); ?>.00 PKR</b>
                                                </td>
                                               
                                            </tr>
                                            <tr class="cart_item">
                                                <th>Rent Date</th>  
                                                <td><span class="amount"><?php echo e($cart['startDate']); ?> to <?php echo e($cart['endDate']); ?></span></td>
                                            </tr>
                                            <tr class="cart_item">
                                                <th>Sub total For <?php echo e($cart['totalDays']); ?> Days</th>  
                                                <td><span class="amount"><?php echo e($cart['priceForTotalDays']); ?>.00 PKR</span></td>
                                            </tr>
                                            <tr class="cart_item">
                                                <th>Security Deposit</th>  
                                                <td><span class="amount"><?php echo e($cart['securityDeposit']); ?>.00 PKR</span></td>
                                            </tr>
                                            <tr class="cart_item">
                                                <th>Extra Service</th>  
                                                <td><span class="amount">Price</span></td>
                                            </tr>

                                            <?php if(isset($cart['extraService'])): ?>
                                            <?php $__currentLoopData = $cart['extraService']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extraService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="cart_item">
                                                <th><?php echo e($extraService->extraPrice->name); ?></th>  
                                                <td><span class="amount"><?php echo e($extraService->value); ?>.00 PKR</span></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr class="cart-subtotal">
                                                <th>Cart Subtotal</th>
                                                <td><span class="amount"><?php echo e($cart['subTotalPrice']); ?>.00 PKR</span></td>
                                            </tr>
                                          
                                            <tr class="order-total">
                                                <th>Order Total</th>
                                                <td><strong><span class="amount"><?php echo e($cart['totalPrice']); ?>.00 PKR</span></strong>
                                                </td>
                                            </tr>								
                                        </tfoot>
                                    </table>
                                </div>
                                <!-- your-order-table end -->
                                
                                <!-- your-order-wrap end -->
                                <div class="payment-method">
                                    <div class="payment-accordion">
                                        <!-- ACCORDION START -->
                                        <h3>Direct Bank Transfer</h3>
                                        <div class="payment-content">
                                            <p>Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won’t be shipped until the funds have cleared in our account.</p>
                                        </div>
                                        <!-- ACCORDION END -->	
                                        <!-- ACCORDION START -->
                                        <h3>Cheque Payment</h3>
                                        <div class="payment-content">
                                            <p>Please send your cheque to Store Name, Store Street, Store Town, Store State / County, Store Postcode.</p>
                                        </div>
                                        <!-- ACCORDION END -->	
                                        <!-- ACCORDION START -->
                                        <h3>PayPal <img src="assets/images/icon/4.png" alt="" /></h3>
                                        <div class="payment-content">
                                            <p>Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.</p>
                                        </div>
                                        <!-- ACCORDION END -->									
                                    </div>
                                    <div class="order-button-payment">
                                        <input type="submit" value="Place order" />
                                    </div>
                                </div>
                                <!-- your-order-wrapper start -->
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- checkout-details-wrapper end -->
        </div>
    </div>
    <!-- content-wraper end -->
             <?php $__env->stopSection(); ?>

<?php echo $__env->make('website/includes/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usama/Desktop/CustomProjects/ecommerceMultiVendor/resources/views/website/checkout.blade.php ENDPATH**/ ?>