<?php $__env->startSection('content'); ?>
    <!-- breadcrumb-area start -->
    <div class="breadcrumb-area bg-grey">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="breadcrumb-list">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Order Confirmation</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumb-area end -->

    <!-- content-wraper start -->
    <div class="content-wraper">
        <div class="container">
            <!-- order-confirmation-wrapper start -->
            <div class="order-confirmation-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="shoping-checkboxt-title">Order Confirmation</h3>
                        <p>Thank you for your order. Here are your order details:</p>
                        <div class="order-details">
                            <h4>Customer Details</h4>
                            <p><strong>Name:</strong> <?php echo e($order->customer_name); ?></p>
                            <p><strong>Email:</strong> <?php echo e($order->email); ?></p>
                            <p><strong>Phone:</strong> <?php echo e($order->phone); ?></p>

                            <h4>Order Details</h4>
                            <p><strong>Order Number:</strong> <?php echo e($order->order_number); ?></p>
                            <p><strong>Order Notes:</strong> <?php echo e($order->order_notes); ?></p>
                            <p><strong>Sub Total:</strong> $<?php echo e(number_format($order->sub_total, 2)); ?></p>
                            <p><strong>Extra Service Total:</strong> $<?php echo e(number_format($order->extra_service_total, 2)); ?></p>
                            <p><strong>Discount:</strong> $<?php echo e(number_format($order->discount, 2)); ?></p>
                            <p><strong>Total Price:</strong> $<?php echo e(number_format($order->total_price, 2)); ?></p>
                            <p><strong>Status:</strong> <?php echo e($order->status); ?></p>
                            <p><strong>Start Date:</strong> <?php echo e($order->start_date); ?></p>
                            <p><strong>End Date:</strong> <?php echo e($order->end_date); ?></p>
                            <p><strong>Total Days:</strong> <?php echo e($order->total_days); ?></p>

                            <h4>Order Line Items</h4>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Price for Total Days</th>
                                        <th>Security Deposit</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $order->lineItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->product->name); ?></td>
                                            <td><?php echo e($item->quantity); ?></td>
                                            <td>PKR <?php echo e(number_format($item->price, 2)); ?></td>
                                            <td>PKR<?php echo e(number_format($item->price_for_total_days, 2)); ?></td>
                                            <td>PKR<?php echo e(number_format($item->security_deposit, 2)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            <h4>Extra Prices</h4>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Extra Price</th>
                                        <th>Value</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $order->extraPrices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extraPrice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($extraPrice->extraPrice->name); ?></td>
                                            <td>PKR<?php echo e(number_format($extraPrice->value, 2)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            <h4>Adjustable Values</h4>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Adjustable ID</th>
                                        <th>Adjustable Value</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $order->adjustables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adjustable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($adjustable->adjustable_id); ?></td>
                                            <td><?php echo e(number_format($adjustable->adjustable_value, 2)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- order-confirmation-wrapper end -->
        </div>
    </div>
    <!-- content-wraper end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website/includes/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usama/Desktop/CustomProjects/ecommerceMultiVendor/resources/views/website/orderConfirmation.blade.php ENDPATH**/ ?>